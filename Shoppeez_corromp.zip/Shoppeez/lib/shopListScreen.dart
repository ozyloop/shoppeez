import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:shoppeez/recipeDatabase.dart';
import 'package:shoppeez/recipeScreen.dart';
import 'package:shoppeez/recipe.dart';

class ShopListScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return ShopListScreenState();
  }

}


class ShopListScreenState extends State<ShopListScreen> {

  int _selectedIndex=2;
  void _onItemTapped(int index) {
    _selectedIndex =index;
    if(_selectedIndex==0) {
      Navigator.pushNamed(context, '/shoppingList',);
    }
    else if(_selectedIndex==1) {

      Navigator.pushNamed(context, '/recipe',);
    } else {
      Navigator.pushNamed( context, '/shopList',);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Mes recettes"),
      ),
      body: FutureBuilder<List<Recipe>>(
          future: RecipeDataBase.instance.recipes(),
          builder: (BuildContext context, AsyncSnapshot<List<Recipe>> snapshot) {
            if (snapshot.hasData) {
              List<Recipe>? recipes = snapshot.data;

              return ListView.builder(
                itemCount: recipes!.length,
                itemBuilder: (context, index) {
                  final recipe = recipes[index];
                  return Dismissible(key: Key(recipe.title),
                      onDismissed: (direction) {
                        setState(() {
                          RecipeDataBase.instance.deleteRecipe(recipe.title);

                        });
                        ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text("${recipe
                                .title} supprimé")));
                      },
                      background: Container(color: Colors.grey),
                      child: RecipeItemWidget(recipe: recipe));
                },


              );
            }
            else {
              return Center(child: Text("No Data"));
            }
          }),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[


          BottomNavigationBarItem(
            icon: Icon(Icons.article),
            label: 'Shopping List',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add_to_home_screen),
            label: 'Recipe',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add_shopping_cart),
            label: 'Shop',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
    );
  }
}

class RecipeItemWidget extends StatelessWidget {
  const RecipeItemWidget({Key? key, required this.recipe}) : super(key: key);
  final Recipe recipe;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onTap: (){
          Navigator.pushNamed(
            context,
            '/recipe',
            arguments: recipe,
          );
        },

        child: Card(
            margin: EdgeInsets.all(8),
            elevation: 4,
            child: Row(
                children: [
                  Hero(
                      tag: "imageRecipe" + recipe.title,
                      child:CachedNetworkImage(
                        imageUrl: recipe.imageUrl,
                        placeholder: (context, url) =>
                            Center(child: CircularProgressIndicator()),
                        errorWidget: (context, url, error) => Icon(Icons.error),
                        width: 100,
                        height: 100,
                        fit: BoxFit.cover,
                      )),
                  Padding(
                      padding: EdgeInsets.all(8),
                      child:Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.only(bottom: 8),
                            child : Text(recipe.title,
                                style:
                                TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
                          ),
                          Text(recipe.user,
                              style: TextStyle(color: Colors.grey[500], fontSize: 16))
                        ],

                      ))
                ]
            )));
  }
}
